import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
#from sklearn.model_selection import train_test_split
#from sklearn.linear_model import LinearRegression

"""
a: Problem Description
Using a dataset of diversity statistics for different companies/organizations, I hope to identify potential
hiring bias across different industries. What is the correlation between an industry and its general demographic diversity? 
If a demographic is highly correlated to a type of company, that industry may exhibit bias in terms of 
demographic selection - in otherwords, ethnic stereotypes. 
"""

# Section 1: Heatmap

# Data ingestion
data = pd.read_csv('./Employee Diversity in Tech.csv', header = 1)

# Remove the date column
data.drop(columns=["Company", "Date"], inplace=True)

# Rearranging the data into something usable
rearranged_data = []
data.fillna(0, inplace=True)
data.replace(' -   ', 0, inplace=True)
data[data.columns[1:9]] = data[data.columns[1:9]].astype(float)
demographic_columns = data.columns[1:9]
for i in range(data.shape[0]):
    # Get the values of the first column and the demographic columns
    row_type = data.iloc[i, 0]
    demographic_values = data.iloc[i, 1:9].tolist()
    # Loop through the demographic columns and values
    for j, demographic in enumerate(demographic_columns):
        # Append the row type, demographic, and demographic value to the rearranged_data list
        rearranged_data.append([row_type, demographic, demographic_values[j]])

# Convert the rearranged_data list to a pandas DataFrame
data = pd.DataFrame(rearranged_data, columns=["Type", "Demographic", "Value"])


"""
b: Dataset introduction
This dataset spans a few years of hiring demographic information for a variety of companies. It breaks down each company
into an industry, and gives information regarding the % of male, female, white, asian, black, etc. employees. I am just 
interested in the relationship of industries to hiring rates, and not specific companies, so I have removed the "Company"
column. Additionally, I am ignoring the timespan so I can experiment with a larger dataset, although I know this can 
cause skewing. The table shows an aggregated modified dataset, while the scatterplot shows a spread of hiring rates 
for specific demographics.
"""
# b - Table 

industry_avg = data.groupby("Demographic")
print(industry_avg)
table = plt.table(cellText=industry_avg, colLabels=data.columns, loc='center')
plt.axis('off')
plt.show()
print(data)
# b - Scatterplot 
import matplotlib.pyplot as plt

x = data["Demographic"]
y = data["Value"]
plt.scatter(x, y)

plt.xlabel('Demographic')
plt.ylabel('Percentage of Company')
plt.title('Scatterplot of Demographic Percentages')
plt.show()

"""
c - Heatmap 
This heatmap can be used to show the correlation of each demographic to the "type" variable (industry). Using the spearman
method, it demonstrates a non-parametric monophonic correlation between the values, providing insight into 
which ethnic groups' hiring rates are heavily affected by the industry they might be trying to work in. 
Additionally, the heatmap shows whether the demographics might correlate strongly with the presence or lack thereof 
of other ethnic groups in the same company - which can be useful for our question to check for conflating forms
of hiring bias. For example, male correlation could be high with "type" and could be highly correlated with "% white",
which means that we cannot assume that industries show heavy bias for males because the data could be skewed by a preference 
of ethnically white individuals for hiring males. 
"""
# Replace NaN values with 0 and ensure everything is a float
y_axis = data["Demographic"].unique()
x_axis = data["Type"].unique()

# Encode the "Type" column
data['Type'] = data['Type'].astype('category')
data['Type'] = data['Type'].cat.codes

# Plot the heatmap
if data.shape[0] > 0:
    corr = data.corr(method = "spearman")
    sns.heatmap(corr, annot=True, xticklabels = x_axis, yticklabels = y_axis)
    plt.title("Correlation between demographic diversity by industry")
else:
    print("Input data is empty, cannot plot heatmap.")
plt.show()

